function bigImg(x) {
    x.style.height = "1000px";
    x.style.width = "1000px";
  }
  
  function normalImg(x) {
    x.style.height = "500px";
    x.style.width = "500px";
  }